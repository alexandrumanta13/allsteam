import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-two',
  templateUrl: './service-two.component.html',
  styleUrls: ['./service-two.component.scss']
})
export class ServiceTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
